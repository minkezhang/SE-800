App = function()
{
    var zoomIn = true;
    
    this.load = function()
    {
        wade.loadImage('assets/sb1.png');
		wade.loadImage('assets/sb2.png');
		wade.loadImage('assets/sb3.png');
		wade.loadImage('assets/sb4.png');
		wade.loadImage('assets/sb5.png');
		wade.loadImage('assets/spacepx2.png');
		//wade.preloadAudio('assets/metegt.aac',true,true);//bgm
    };
	
    
    this.init = function()
    {
		//background
		var bg1 = new Sprite('',5);
		var ani1 = new Animation('assets/sb1.png', 1, 1, 0.07, 1, 0, 0);
		ani1.setBlending(true);
		bg1.addAnimation('b1', ani1);
		var bgd1 = new SceneObject(bg1);
        wade.addSceneObject(bgd1);
		bg1.playAnimation('b1');
		bgd1.moveTo(960, 0, 0);
		var bg2 = new Sprite('',4);
		var ani2 = new Animation('assets/sb2.png', 1, 1, 0.07, 1, 0, 0);
		ani2.setBlending(true);
		bg2.addAnimation('b2', ani2);
		var bgd2 = new SceneObject(bg2);
        wade.addSceneObject(bgd2);
		bg2.playAnimation('b2');
		bgd2.moveTo(960, 0, -2);
		var bg3 = new Sprite('',3);
		var ani3 = new Animation('assets/sb3.png', 1, 1, 0.07, 1, 0, 0);
		ani3.setBlending(true);
		bg3.addAnimation('b3', ani3);
		var bgd3 = new SceneObject(bg3);
        wade.addSceneObject(bgd3);
		bg3.playAnimation('b3');
		bgd3.moveTo(960, 0, -4);
		var bg4 = new Sprite('',2);
		var ani4 = new Animation('assets/sb4.png', 1, 1, 0.07, 1, 0, 0);
		ani4.setBlending(true);
		bg4.addAnimation('b4', ani4);
		var bgd4 = new SceneObject(bg4);
        wade.addSceneObject(bgd4);
		bg4.playAnimation('b4');
		bgd4.moveTo(2, 0, -4);
		/*bgd4.onMoveComplete = function()
        {
            var clone = bgd4.clone();
			clone.setPosition(0, 0);
			wade.addSceneObject(clone);
			clone.moveTo(960, 0, -32);
        };*/
    };
};