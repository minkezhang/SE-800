App = function()
{
    this.load = function()
    {
		wade.preloadAudio('assets/metegt.aac',true,true);//bgm
    };
	
    
    this.init = function()
    {
		
    };
};