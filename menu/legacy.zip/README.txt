Menu System for SE-800
Seun Ogedengbe

use:
open index.html in a html 5 compatible browser

tested in firefox