/* CMSC23800 Sample code
 *
 * COPYRIGHT (c) 2014 Oluwaseun Ogedengbe
 * All rights reserved.
 */

#ifndef _NET_H_
#define _NET_H_

struct netstruct{
//	client-info
    int		dhost_bl;//dynamic host boolean
	int		aconn_bl;//accept connections boolean
	char *	host;//might change with a new host
	char *	port;//typically hard coded
//	sending packet
	int		delivery;
//	receiving packet
	int		recption;
};

extern netstruct *ndata;  

#endif /* !_NET_H_ */
