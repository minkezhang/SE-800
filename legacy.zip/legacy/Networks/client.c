/* CMSC23800
 *
 * COPYRIGHT (c) 2014 Oluwaseun Ogedengbe
 * All rights reserved.
 */
/*A client that connects to a server;
can spawn server if it doesn't exist;
Networking in C++ offers view benefits;*/

#include "net.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <process.h>

//netstruct *ndata = &data;

/*int spwnsvr(int hd, int ac)
{//spawn a server
	pid_t process;
	process = fork();
	char * hdyn;
	char * acon;
	sprintf(hdyn,"%d",hd);
	sprintf(acon,"%d",ac);

	if (process < 0){
	   //fork error
	   perror("fork");
	   exit(EXIT_FAILURE);
	}
	if (process == 0){
		if (execl("./server.exe", hdyn, acon, NULL)< 0){//need to pass args to server
			perror("execv");
			exit(EXIT_FAILURE);
	   }
	}
	return 0;
}

int unpack(char* x)
{
	return 1;
}

int main(int argc, char *argv[])
{
	netstruct data;
	//data = NULL;
	//data.dhost_bl = NULL;//dynamic host boolean
	//data.aconn_bl = NULL;//accept connections boolean
	//data.host = NULL;//might change with a new host
	//data.port = NULL
	data.delivery = NULL;
	data.recption = NULL;
	//int hostdyn = 0; //dynamic host; allows host migration
	//int acccon = 0; //accepts connections
    //initialize connection data
    int clientSocket;
    struct addrinfo hints, // Used to provide hints to getaddrinfo()
    *res,  // Used to return the list of addrinfo's
    *p;    // Used to iterate over this list
    //char *host, *port;
    char buffer[100 + 1]; // +1 for '\0'
    int nbytes;
    //host = NULL;
    //port = NULL;
    
	while(data.host == NULL && data.port == NULL){
		sleep(5);//sleep till you get a port and host
	}
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
	while (1)
	{//(hostdyn, acccon)
	// Single Player (0,0), no one else can play with you, all connections are refused, host locked to initial user
	// Cooperative Play (0,1), others can play with you, all connections accepted, host locked to initial user
	// Multiplayer (1,1), others can play with you, all connections accepted, host migrates
		if (!data.dhost_bl)//if single player spawn server
		{
			reHOST:
			spwnsvr(data.dhost_bl,data.aconn_bl);
		}
        //hardcoded port; assume server is on same machine
		if (getaddrinfo(data.host, data.port, &hints, &res) != 0)
		{
			perror("getaddrinfo() failed");
			printf("retrying");
			continue;
		}
		break;
	}
	for(p = res;p != NULL; p = p->ai_next) 
	{//setting up socket
		if ((clientSocket = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) 
		{
			perror("Could not open socket");
			continue;
		}
		if (connect(clientSocket, p->ai_addr, p->ai_addrlen) == -1) 
		{
			close(clientSocket);
			perror("Could not connect to socket");
			continue;
		}
		break;
	}/*
	/* We don't need the linked list any-more. Free it. */
	/*freeaddrinfo(res);
	
	nbytes = 1;
	int count = 0;
	while (nbytes){
		// Read from the socket 
		nbytes = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
		if (nbytes == 0)
		{
			perror("Server closed the connection");
			goto reHOST;
		}
		else if (nbytes == -1)
		{
			perror("Socket recv() failed");
			close(clientSocket);
			goto reHOST;
			exit(-1);
		}
		else
		{//unpack and send to extern;
			data = unpack(buffer);
		}
		//count++;
		if (count > 10) break;
		//client auto shutdown
	}
	close(clientSocket);
	return 0;
}
*/