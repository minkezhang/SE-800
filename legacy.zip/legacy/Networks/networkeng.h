#ifndef NETWORKENG_H_   
#define NETWORKENG_H_
int foo(int x);  /* An example function declaration */

extern char *port;
extern char *host;
extern int hostdyn;
extern int acccon;

typedef struct foo {
    int i;
} recieve;

int unpack(char* x);

extern recieve *takepack;
#endif