/*A client that connects to a server; can spawn server if it doesn't exist*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <process.h>

int spwnsvr(int hd, int ac)
{//spawn a server
	pid_t process;
	process = fork();
	char * hdyn;
	char * acon;
	sprintf(hdyn,"%d",hd);
	sprintf(acon,"%d",ac);

	if (process < 0){
	   //fork error
	   perror("fork");
	   exit(EXIT_FAILURE);
	}
	if (process == 0){
		if (execl("./server.exe", hdyn, acon, NULL)< 0){//need to pass args to server
			perror("execv");
			exit(EXIT_FAILURE);
	   }
	}
	return 0;
}

int main(int argc, char *argv[])
{
	char input;
	int hostdyn = 0; //dynamic host; allows host migration
	int acccon = 0; //accepts connections
    //initialize connection data
    int clientSocket;
    struct addrinfo hints, // Used to provide hints to getaddrinfo()
    *res,  // Used to return the list of addrinfo's
    *p;    // Used to iterate over this list
    char *host, *port;
    char buffer[100 + 1]; // +1 for '\0'
    int nbytes;
    host = strdup("localhost");
    port = strdup("23300");
    
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
	printf("Project: SE-800\n1. Single Player\n2. Multi Player\n3. Exit\n");
	while (1)
	{
		input = getchar();
		switch (input)
		{
			case '1':
				printf("singleplayer\n1. Solo\n2. Coop");
                fflush(stdin);
				input = getchar();
				if (input-1) acccon = 1;
				break;
			case '2':
				printf("multiplayer\n");
				hostdyn = 1;
				break;
			case '3':
				return 0;
			default:
				printf("Unknown option\n");
				continue;
		}
		if (!hostdyn)
		{
			reHOST:
			spwnsvr(hostdyn,acccon);
		}
        //hardcoded port; assume server is on same machine
		if (getaddrinfo(host, port, &hints, &res) != 0)
		{
			perror("getaddrinfo() failed");
			printf("retrying");
			continue;
		}
		break;
	}
	for(p = res;p != NULL; p = p->ai_next) 
	{
		if ((clientSocket = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) 
		{
			perror("Could not open socket");
			continue;
		}
		if (connect(clientSocket, p->ai_addr, p->ai_addrlen) == -1) 
		{
			close(clientSocket);
			perror("Could not connect to socket");
			continue;
		}
		break;
	}
	/* We don't need the linked list any more. Free it. */
	freeaddrinfo(res);
	
	nbytes = 1;
	int count = 0;
	while (nbytes){
		/* Read from the socket */
		nbytes = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
		if (nbytes == 0)
		{
			perror("Server closed the connection");
			goto reHOST;
		}
		else if (nbytes == -1)
		{
			perror("Socket recv() failed");
			close(clientSocket);
			goto reHOST;
			exit(-1);
		}
		else
		{
			/* The message doesn't have a '\0' at the end. Add one so we
			   can print it */
			buffer[nbytes] = '\0';
			printf("Received this message:\n<<%s>>\n", buffer);
		}
		count++;
		if (count > 10) break;
		//client auto shutdown
	}
	close(clientSocket);
	return 0;
}
