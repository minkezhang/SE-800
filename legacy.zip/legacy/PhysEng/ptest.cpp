#include "physics.h"
#include <iostream>

using namespace std;

int test_rotation() {
	Projectile Pobj(1, 0, 100.0, 1000.0);
	vector<float> ytest = {0,0,1};
	vector<float> rtest = {1,0,0};
	vector<float> ptest = {0,1,0};
	Pobj.set_y(ytest);
	Pobj.set_r(rtest);
	Pobj.set_p(ptest);
	cout << "roll: " << rtest.at(0) << ", " << rtest.at(1) << ", "<< rtest.at(2) << '\n';
	cout << "pitch: " << ptest.at(0) << ", " << ptest.at(1) << ", "<< ptest.at(2) << '\n';
	cout << "yaw: " << ytest.at(0) << ", " << ytest.at(1) << ", "<< ytest.at(2) << '\n' << '\n';
	PhysicsEngine peng;
	peng.apply_rotation(1.57079633,0, &Pobj);
	peng.apply_rotation(1.57079633,1, &Pobj);
	peng.apply_rotation(1.57079633,0, &Pobj);
	peng.apply_rotation(1.57079633,0, &Pobj);
	peng.apply_rotation(1.57079633,0, &Pobj);
	peng.apply_rotation(1.57079633,0, &Pobj);
	peng.apply_rotation(-1.57079633,1, &Pobj);
	peng.apply_rotation(-1.57079633,0, &Pobj);
	vector<float> roty = Pobj.get_y();
	vector<float> rotr = Pobj.get_r();
	vector<float> rotp = Pobj.get_p();
	cout << "roll: " << rotr.at(0) << ", " << rotr.at(1) << ", " << rotr.at(2) << '\n';
	cout << "pitch: " << rotp.at(0) << ", " << rotp.at(1) << ", " << rotp.at(2) << '\n';
	cout << "yaw: " << roty.at(0) << ", " << roty.at(1) << ", " << roty.at(2) << '\n';
	if ((rotr.at(0) >= 0.99 && rotr.at(0) <= 1.01) && (rotr.at(1) >= -0.1 && rotr.at(1) <= 0.1) &&
		(rotr.at(2) >= -0.01 && rotr.at(2) <= 0.01)) {
		cout << "roll_success!\n";
		if ((rotp.at(0) >= -0.01 && rotp.at(0) <= 0.01) && (rotp.at(1) >= 0.99 && rotp.at(1) <= 1.01) &&
		(rotp.at(2) >= -0.01 && rotp.at(2) <= 0.01)) {
			cout << "pitch_success!\n";
			if ((roty.at(0) >= -0.01 && roty.at(0) <= 0.01) && (roty.at(1) >= -0.01 && roty.at(1) <= 0.01) &&
			(roty.at(2) >= 0.99 && roty.at(2) <= 1.01)) {
				cout << "yay_success!\n";
				return 1;
			}
		}
	}
	return 0;
}

int test_verlet() {
	Projectile Pobj(1, 0, 100.0, 1000.0);
	vector<float> ytest = {0,0,1};
	vector<float> rtest = {1,0,0};
	vector<float> ptest = {0,1,0};
	Pobj.set_y(ytest);
	Pobj.set_r(rtest);
	Pobj.set_p(ptest);
	Pobj.set_r_dot(0);
	Pobj.set_p_dot(1.57079633);
	vector<float> vtest1 = {10,0,0};
	vector<float> dtest1 = {0,0,0};
	Pobj.set_v(vtest1);
	Pobj.set_d(dtest1);
	Pobj.set_a(10.0);
	cout << "Initial velocity: (" << vtest1.at(0) << ", " << vtest1.at(1) << ", " << vtest1.at(2) << ")\n";
	cout << "Initial position: (" << dtest1.at(0) << ", " << dtest1.at(1) << ", " << dtest1.at(2) << ")\n";
	PhysicsEngine peng;
	peng.verlet_step(1, &Pobj);
	vector<float> vtest2 = Pobj.get_v();
	vector<float> dtest2 = Pobj.get_d();
	cout << "Final velocity: (" << vtest2.at(0) << ", " << vtest2.at(1) << ", " << vtest2.at(2) << ")\n";
	cout << "Final position: (" << dtest2.at(0) << ", " << dtest2.at(1) << ", " << dtest2.at(2) << ")\n";
	peng.verlet_step(5, &Pobj);
	vector<float> vtest3 = Pobj.get_v();
	vector<float> dtest3 = Pobj.get_d();
	cout << "Final velocity: (" << vtest3.at(0) << ", " << vtest3.at(1) << ", " << vtest3.at(2) << ")\n";
	cout << "Final position: (" << dtest3.at(0) << ", " << dtest3.at(1) << ", " << dtest3.at(2) << ")\n";

	return 1;
}

int main() {
	int result1 = test_rotation();
	cout << result1 << '\n';
	int result2 = test_verlet();
	cout << result2 << '\n';
	return 0;
}

