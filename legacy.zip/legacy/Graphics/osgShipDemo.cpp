// DEMO WHICH LOADS SHIP AND ASTEROID MODEL AND HAS SIMPLE
// KEYBOARD CONTROL: 
// w to roll right
// e to roll left
// r to move forward
// MUST HAVE astroid.obj AND ship.obj IN BINARY DIRECTORY

#include <osg/Node>
#include <osg/PositionAttitudeTransform>
#include <osgDB/ReadFile>
#include <osgViewer/Viewer>
#include <osgGA/TrackballManipulator>
#include <osg/MatrixTransform>
#include <osg/Matrixd>
#include <osg/NodeCallback>
#include <osg/Quat>
#include <osg/Vec3>


// Ship pos is global to account for camera and node callback having access to
// ship position.
osg::Vec3d shipPos;

// Types of requests a ship can handle.
class shipInputDeviceStateType
{
 public:
  shipInputDeviceStateType() :
    rollRightRequest(false), rollLeftRequest(false), moveFwdRequest(false) {}
  bool rollRightRequest;
  bool rollLeftRequest;
  bool moveFwdRequest;
};

// Detect when keys are pressed, set events.
class myKeyboardEventHandler : public osgGA::GUIEventHandler
{
 public:
  myKeyboardEventHandler(shipInputDeviceStateType* sids) {
    shipInputDeviceState = sids;
  }

  virtual bool handle(const osgGA::GUIEventAdapter& ea, osgGA::GUIActionAdapter&) {
    switch(ea.getEventType()) {
      case(osgGA::GUIEventAdapter::KEYDOWN):
        {
          switch(ea.getKey()) {
            case 'w':
              std::cout << "w key pressed" << std::endl;
              shipInputDeviceState->rollRightRequest = true;
              return false;
              break;
            case 'e':
              std::cout << "e key pressed" << std::endl;
              shipInputDeviceState->rollLeftRequest = true;
              return false;
              break;
            case 'r':
              std::cout << "r key pressed" << std::endl;
              shipInputDeviceState->moveFwdRequest = true;
              return false;
              break;
            default:
              return false;
          }
        }
      case(osgGA::GUIEventAdapter::KEYUP):
        {
          switch(ea.getKey()) {
            case'w':
              shipInputDeviceState->rollRightRequest = false;
              return false;
              break;
            case 'e':
              shipInputDeviceState->rollLeftRequest = false;
              return false;
              break;
            case 'r':
              shipInputDeviceState->moveFwdRequest = false;
              return false;
              break;
          }
        }
      case(osgGA::GUIEventAdapter::MOVE):
        {
          std::cout << "X IS " << ea.getXnormalized() << std::endl;
          std::cout << "Y IS " << ea.getYnormalized() << std::endl;
        }
      default:
        return false;
    }
  }

  virtual void accept(osgGA::GUIEventHandlerVisitor& v) {
    v.visit(*this); 
  }
 protected:
  shipInputDeviceStateType* shipInputDeviceState;
};

// How to update objects based on object request state.
class updateShipPosCallback : public osg::NodeCallback {
 public:
  updateShipPosCallback(shipInputDeviceStateType* shipIDevState)
      : rotation(0.0) /*, shipPos(0.0,0.0,0.0)*/ {
    shipPos.set(0.0,0.0,0.0);
    shipInputDeviceState = shipIDevState;
  }

  virtual void operator()(osg::Node* node, osg::NodeVisitor* nv) {
    osg::PositionAttitudeTransform* pat =
        dynamic_cast<osg::PositionAttitudeTransform*> (node);
    if (pat) {
      if (shipInputDeviceState->moveFwdRequest) {
        shipPos.set(shipPos.x(),shipPos.y()+0.1,shipPos.z());
        pat->setPosition(shipPos);
      }
      if (shipInputDeviceState->rollRightRequest) {
        // Only roll ship up to a specified degree.
        if (rotation <= 30.0) {
          rotation += 0.1;
        }
        osg::Quat newAttitude = (osg::Quat(osg::DegreesToRadians(-90.0f), osg::Vec3d(0, 0, 1)))*
                                (osg::Quat(osg::DegreesToRadians(25.0f), osg::Vec3d(1, 0, 0)))*
                                (osg::Quat(osg::DegreesToRadians(rotation), osg::Vec3d(0, 1, 0)));
        pat->setAttitude(newAttitude);
      }

      else if (shipInputDeviceState->rollLeftRequest) {
        // Only roll ship up to a specified degree.
        if (rotation >= -30.0) {
          rotation -= 0.1;
        }
        osg::Quat newAttitude = (osg::Quat(osg::DegreesToRadians(-90.0f), osg::Vec3d(0, 0, 1)))*
                                (osg::Quat(osg::DegreesToRadians(25.0f), osg::Vec3d(1, 0, 0)))*
                                (osg::Quat(osg::DegreesToRadians(rotation), osg::Vec3d(0, 1, 0)));
        pat->setAttitude(newAttitude);
      }

    }
    traverse(node, nv);
  }


 protected:
  // osg::Vec3d shipPos;
  float rotation;
  shipInputDeviceStateType* shipInputDeviceState;
};


int main() {

  osg::Node* shipNode = NULL;
  osg::Node* asteroidNodeOne = NULL;
  osg::Node* asteroidNodeTwo = NULL;

  shipNode = osgDB::readNodeFile("ship.obj");
  asteroidNodeOne = osgDB::readNodeFile("asteroid.obj");
  asteroidNodeTwo = osgDB::readNodeFile("asteroid.obj");
  
  /* Declare a node which will serve as the root node
   * for the scene graph. Since we will be adding nodes
   * as 'children' of this node we need to make it a 'group'
   * instance.
   * The 'node' class represents the most generic version of nodes.
   * This includes nodes that do not have children (leaf nodes.)
   * The 'group' class is a specialized version of the node class.
   * It adds functions associated with adding and manipulating
   * children.
  */
   
  osg::Group* root = new osg::Group();
   
  // Declare transform, initialize with defaults.
  osg::PositionAttitudeTransform* shipXform =
       new osg::PositionAttitudeTransform();
  osg::PositionAttitudeTransform* astrOneXform =
       new osg::PositionAttitudeTransform();
  osg::PositionAttitudeTransform* astrTwoXform =
       new osg::PositionAttitudeTransform();
  
	   
  // Use the 'addChild' method of the osg::Group class to
  // add the transform as a child of the root node and the
  // tank node as a child of the transform.
   
  root->addChild(shipXform);
  root->addChild(astrOneXform);
  root->addChild(astrTwoXform);

  shipXform->addChild(shipNode);
  astrOneXform->addChild(asteroidNodeOne);
  astrTwoXform->addChild(asteroidNodeTwo);
   
  // Declare and initialize a Vec3 instance to change the
  // position of the ship model in the scene.
  osg::Vec3 shipPosit(0, 0, 0);
  shipXform->setAttitude((osg::Quat(osg::DegreesToRadians(-90.0f),
                          osg::Vec3d(0, 0, 1)))*(osg::Quat(osg::DegreesToRadians(25.0f),
                          osg::Vec3d(1, 0, 0))));
  shipXform->setPosition(shipPosit);

  // First asteroid is farther away and to the left of the ship.
  osg::Vec3 astrOnePosit(-15, 50, 12);
  // Second asteroid is closer and to the right of the ship (x, z, y)
  osg::Vec3 astrTwoPosit(15, 25, 13);
  astrOneXform->setPosition(astrOnePosit);
  astrTwoXform->setPosition(astrTwoPosit);
  astrOneXform->setScale(osg::Vec3(0.5,0.5,0.5));
  astrTwoXform->setScale(osg::Vec3(0.5,0.5,0.5));

  // Declare and set camera matrix
  osg::Matrixd myCameraMatrix;
  osg::Matrixd cameraRotation;
  osg::Matrixd cameraTrans;
  cameraRotation.makeRotate(
      osg::DegreesToRadians(0.0), osg::Vec3(0,1,0),  // roll
      osg::DegreesToRadians(0.0), osg::Vec3(1,0,0),  // pitch
      osg::DegreesToRadians(0.0), osg::Vec3(0,0,1));  // heading

  // Declare instance of class to record state of keyboard
  shipInputDeviceStateType* sIDevState = new shipInputDeviceStateType;

  // Set up the ship update callback
  //  Pass the constructor a pointer to our ship input device state that we
  //  declared above.
  shipXform->setUpdateCallback(new updateShipPosCallback(sIDevState));

  // The constructor for our event handler also gets a pointer to our ship
  //  input device state instance.
  myKeyboardEventHandler* shipEventHandler = new myKeyboardEventHandler(sIDevState);

  // Declare a 'viewer'
  osgViewer::Viewer viewer;
   
  // Next we will need to assign the scene graph we created
  // above to this viewer.
  viewer.setSceneData(root);
   
  // Add our event handler to the list.
  viewer.addEventHandler(shipEventHandler);
   
  // Create the windows and start the required threads.
  viewer.realize();
   
  // Enter the simulation loop. viewer.done() returns false
  // until the user presses the 'esc' key.
  // (This can be changed by adding your own keyboard/mouse
  // event handler or by changing the settings of the default
  // keyboard/mouse event handler)
   
  while(!viewer.done()) {
     // Dispatch the new frame, this wraps the follow Viewer operations:
	 //     advance() to the new frame
	 //     eventTraversal() that collects events and passes them on to the 
	 // event handlers and event callbacks
	 //     updateTraversal() to call the update callbacks
	 //     renderingTraversals() that runs synchronizes all the rendering threads
	 // (if any) and dispatch cull, draw, and swap buffers

      // Declare and set camera matrix to follow ship
      cameraTrans.makeTranslate(shipPos.x()-1, shipPos.y()-27, shipPos.z()+8);
      myCameraMatrix = cameraRotation * cameraTrans;
      osg::Matrixd i = myCameraMatrix.inverse(myCameraMatrix);
      viewer.getCamera()->setViewMatrix( (
          myCameraMatrix.inverse(myCameraMatrix) *
          osg::Matrixd::rotate(-M_PI/2.0, 1, 0, 0)));

    viewer.frame();
  }	  
}
